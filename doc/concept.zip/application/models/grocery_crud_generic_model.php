<?php
class grocery_CRUD_Generic_Model extends grocery_CRUD_Model  {

    public $ESCAPE_CHAR = '"';
    public $CAPABLE_CONCAT = TRUE;

    public function __construct(){
        parent::__construct();

        $test = $this->protect_identifiers('t');
        $first_char = substr($test,0,1);
        if($first_char !== 't'){
            $this->ESCAPE_CHAR = $first_char;
        }
    }

    public function protect_identifiers($value)  {
        return $this->db->protect_identifiers($value);
    }

    public function build_concat_from_template($template, $prefix_replacement='', $suffix_replacement='', $as=NULL){
        if($this->CAPABLE_CONCAT)
            $concat_str = "CONCAT('" . str_replace(array("{", "}"), array("', COALESCE(".$prefix_replacement, $suffix_replacement.", ''),'"), str_replace("'","\\'",$template)) . "')";
        else
            $concat_str = "('" . str_replace(array("{", "}"), array("' || COALESCE(".$replacement, ", '') || '"), str_replace("'","\\'",$template)) . "')";

        if(isset($as))
            $concat_str .= " as ".$as;
    }

    function get_list() {
    	if($this->table_name === null) return false;

        $select = $this->protect_identifiers("{$this->table_name}") . ".*";

        $additional_fields = array();
    	if(!empty($this->relation)) {
    		foreach($this->relation as $relation) {
    			list($field_name, $related_table, $related_field_title) = $relation;
    			$unique_join_name = $this->_unique_join_name($field_name);
    			$unique_field_name = $this->_unique_field_name($field_name);

				if(strstr($related_field_title,'{')) {
					$related_field_title = str_replace(" ", "&nbsp;", $related_field_title);
                    $select .= ", ".$this->build_concat_from_template(
                        $related_field_title,
                        $this->protect_identifiers($unique_join_name).".".$this->ESCAPE_CHAR,
                        $this->ESCAPE_CHAR,
                        $this->protect_identifiers($unique_field_name)
                    );
    			} else {
    				$select .= ', ' . $this->protect_identifiers($unique_join_name. '.'. $related_field_title).' AS '. $this->protect_identifiers($unique_field_name);
    			}

    			if($this->field_exists($related_field_title)){
    			    $additional_fields[$this->table_name. '.'. $related_field_title] = $related_field_title;
    			}
    		}
    	}

    	if(!empty($this->relation_n_n)) {
			$select = $this->relation_n_n_queries($select);
    	}

    	$this->db->select($select, false);
    	$results = $this->db->get($this->table_name)->result();

        for($i=0; $i<count($results); $i++){
            foreach($additional_fields as $alias=>$real_field){
                $results[$i]->{$alias} = $results[$i]->{$real_field};
            }
        }

    	return $results;
    }

    protected function relation_n_n_queries($select) {
    	$this_table_primary_key = $this->get_primary_key();
    	foreach($this->relation_n_n as $relation_n_n) {
    		list($field_name, $relation_table, $selection_table, $primary_key_alias_to_this_table, $primary_key_alias_to_selection_table, $title_field_selection_table, $priority_field_relation_table) = array_values((array)$relation_n_n);

    		$primary_key_selection_table = $this->get_primary_key($selection_table);

	    	$field = "";
	    	$use_template = strpos($title_field_selection_table,'{') !== false;
	    	$field_name_hash = $this->_unique_field_name($title_field_selection_table);
	    	if($use_template) {
	    		$title_field_selection_table = str_replace(" ", "&nbsp;", $title_field_selection_table);
                $field .= $this->build_concat_from_template($this->protect_identifiers($title_field_selection_table));
	    	} else {
	    		$field .= $this->protect_identifiers($selection_table.'.'.$title_field_selection_table);
	    	}

    		// Sorry Codeigniter but you cannot help me with the subquery!
    		$select .= ", ". $this->build_relation_n_n_subquery($field, $selection_table, $relation_table, $primary_key_alias_to_selection_table, $primary_key_selection_table, $primary_key_alias_to_this_table, $field_name);
        }

    	return $select;
    }

    /**
     * (non-PHPdoc)
     * @see Grocery_crud_model::like()
     *
     * Function for single searching by method
     */
    public function like($field, $match = '', $side = 'both') {
        // checking data type from table
        $check = $this->db->select("pg_typeof({$field}) as field_type from {$this->table_name}")->get();
        foreach($check->result() as $types){
            $type = strtolower($types->field_type);
        }

        $matchChar = preg_match('/^character/', $type, $matches, PREG_OFFSET_CAPTURE);
        if($matchChar == true) {
            // if data type was character
            $this->db->like($field, $match, $side);
        }else{
            // if data type wasn't character
            $this->db->like("cast({$field} as text)", $match, $side);
        }
    }

    /**
     *
     * @param unknown $table
     * @param string $field
     * @param string $result
     * @param string $getObject
     */
    protected function getTableColumns($table, $field = false, $result = false, $getObject = false){
        $where = false;
        if($field != false){
            $where = "  and column_name = '{$field}' ";
        }
        $sql = "column_name, data_type from information_schema.columns where table_name = '{$table}' {$where}";
        $query = $this->db->select($sql)->get();
        $data = $query->result();

        if($data){
            if($result == 'row'){
                if($getObject == 'name'){
                    return $data[0]->column_name;
                }elseif($getObject == 'type'){
                    return $data[0]->data_type;
                }else{
                    return $data[0];
                }
            }else{
                return $data;
            }
        }
    }

    /**
     * (non-PHPdoc)
     * @see Grocery_crud_model::or_like()
     *
     * Function for multiple or all searching by method
     */
    public function or_like($field, $match = '', $side = 'both', $type = array()) {
        $getType = $this->get_field_types($this->table_name);
        foreach ($getType as $data){
            if($data->type){
                $type[$data->name] = $data->type;
            }
        }
        if(isset($type[$field])){
            if($type[$field] == 'varchar')
                $this->db->or_like($field, $match, $side, false);
            else
                $this->db->or_like("cast({$field} as text)", $match, $side, false);
        }
    }

    function get_total_results() {
    	//set_relation_n_n special queries. We prefer sub queries from a simple join for the relation_n_n as it is faster and more stable on big tables.
    	if(!empty($this->relation_n_n)) {
    		$select = $this->protect_identifiers($this->table_name).'.'.'*';
    		$select = $this->relation_n_n_queries($select);
    		$this->db->select($select,false);

    		return $this->db->get($this->table_name)->num_rows();
    	}

    	return $this->db->count_all_results($this->table_name);
    }

    function join_relation($field_name, $related_table, $related_field_title) {
		$related_primary_key = $this->get_primary_key($related_table);

		if($related_primary_key !== false) {
			$unique_name = $this->_unique_join_name($field_name);
			$this->build_db_join_relation($related_table, $unique_name, $related_primary_key, $field_name);
			$this->relation[$field_name] = array($field_name, $related_table, $related_field_title);

			return true;
		}

    	return false;
    }

    function get_relation_array($field_name, $related_table, $related_field_title, $where_clause, $order_by, $limit = null, $search_like = null) {
    	$relation_array = array();
    	$field_name_hash = $this->_unique_field_name($field_name);
    	$related_primary_key = $this->get_primary_key($related_table);
    	$select = $this->protect_identifiers($related_table).'.'.$this->protect_identifiers($related_primary_key).', ';

    	if(strstr($related_field_title,'{')) {
    		$related_field_title = str_replace(" ", "&nbsp;", $related_field_title);
            $select .= $this->build_concat_from_template(
                $related_field_title,
                $this->ESCAPE_CHAR,
                $this->ESCAPE_CHAR,
                $this->protect_identifiers($field_name_hash)
            );
    	} else {
	    	$select .= $this->protect_identifiers($related_table.'.'.$related_field_title).' as '.$this->protect_identifiers($field_name_hash);
    	}

    	$this->db->select($select,false);
    	if($where_clause !== null)
    		$this->db->where($where_clause);

    	if($where_clause !== null)
    		$this->db->where($where_clause);

    	if($limit !== null)
    		$this->db->limit($limit);

    	if($search_like !== null)
    		$this->db->having($this->protect_identifiers($field_name_hash)." LIKE '%".$this->db->escape_like_str($search_like)."%'");

    	$order_by !== null
    		? $this->db->order_by($order_by)
    		: $this->db->order_by($field_name_hash);

    	$results = $this->db->get($related_table)->result();

    	foreach($results as $row) {
    		$relation_array[$row->$related_primary_key] = $row->$field_name_hash;
    	}

    	return $relation_array;
    }

    function get_relation_n_n_selection_array($primary_key_value, $field_info) {
    	$select = "";
    	$related_field_title = $field_info->title_field_selection_table;
    	$use_template = strpos($related_field_title,'{') !== false;;
    	$field_name_hash = $this->_unique_field_name($related_field_title);
    	if($use_template) {
    		$related_field_title = str_replace(" ", "&nbsp;", $related_field_title);
            $select .= $this->build_concat_from_template(
                $related_field_title,
                $this->ESCAPE_CHAR,
                $this->ESCAPE_CHAR,
                $this->protect_identifiers($field_name_hash)
            );
    	} else {
    		$select .= "$related_field_title as $field_name_hash";
    	}
    	$this->db->select('*, '.$select,false);

    	$selection_primary_key = $this->get_primary_key($field_info->selection_table);

    	if(empty($field_info->priority_field_relation_table)) {
    		if(!$use_template)
    			$this->db->order_by("{$field_info->selection_table}.{$field_info->title_field_selection_table}");
    	} else {
    		$this->db->order_by("{$field_info->relation_table}.{$field_info->priority_field_relation_table}");
    	}
    	$this->db->where($field_info->primary_key_alias_to_this_table, $primary_key_value);
    	$this->db->join(
			$field_info->selection_table,
			"{$field_info->relation_table}.{$field_info->primary_key_alias_to_selection_table} = {$field_info->selection_table}.{$selection_primary_key}"
		);
    	$results = $this->db->get($field_info->relation_table)->result();

    	$results_array = array();
    	foreach($results as $row) {
    		$results_array[$row->{$field_info->primary_key_alias_to_selection_table}] = $row->{$field_name_hash};
    	}

    	return $results_array;
    }

    function get_relation_n_n_unselected_array($field_info, $selected_values) {
    	$use_where_clause = !empty($field_info->where_clause);

    	$select = "";
    	$related_field_title = $field_info->title_field_selection_table;
    	$use_template = strpos($related_field_title,'{') !== false;
    	$field_name_hash = $this->_unique_field_name($related_field_title);

    	if($use_template) {
    		$related_field_title = str_replace(" ", "&nbsp;", $related_field_title);
            $select .= $this->build_concat_from_template(
                    $related_field_title,
                    $this->ESCAPE_CHAR,
                    $this->ESCAPE_CHAR,
                    $this->protect_identifiers($field_name_hash)
                );
    	} else {
    		$select .= "$related_field_title as $field_name_hash";
    	}
    	$this->db->select('*, '.$select,false);

    	if($use_where_clause){
    		$this->db->where($field_info->where_clause);
    	}

    	$selection_primary_key = $this->get_primary_key($field_info->selection_table);
        if(!$use_template)
        	$this->db->order_by("{$field_info->selection_table}.{$field_info->title_field_selection_table}");
        $results = $this->db->get($field_info->selection_table)->result();

        $results_array = array();
        foreach($results as $row) {
            if(!isset($selected_values[$row->$selection_primary_key]))
                $results_array[$row->$selection_primary_key] = $row->{$field_name_hash};
        }

        return $results_array;
    }

    function get_field_types_basic_table() {
    	$db_field_types = array();
        foreach($this->get_field_types($this->table_name) as $db_field_type) {
    	    $db_type = $db_field_type->type;
            $length = $db_field_type->max_length;
            $db_field_types[$db_field_type->name]['db_max_length'] = $length;
            $db_field_types[$db_field_type->name]['db_type'] = $db_type;
            $db_field_types[$db_field_type->name]['db_null'] = true;
            $db_field_types[$db_field_type->name]['db_extra'] = '';
    	}

    	$results = $this->get_field_types($this->table_name);
    	foreach($results as $num => $row) {
    		$row = (array)$row;
    		$results[$num] = (object)( array_merge($row, $db_field_types[$row['name']])  );
    	}
    	return $results;
    }

    function get_field_types($table_name) {
        $results = $this->db->field_data($table_name);
        // some driver doesn't provide primary_key information
        foreach($results as $num => $row) {
            $row = (array)$row;
            if(!array_key_exists('primary_key', $row)){
                $results[$num]->primary_key = 0;
            }
        }
        return $results;
    }

    function db_insert($post_array) {
        $insert = $this->db->insert($this->table_name,$post_array);
        if($insert) {
            $primary_key = $this->get_primary_key();
            // if user already define a value for the primary key, then just return it
            // postgresql use LASTVAL() to retrieve insert_id which would cause an error if the sequence is not used.
            if(array_key_exists($primary_key, $post_array)){
                return $post_array[$primary_key];
            }
            return $this->db->insert_id();
        }
        return false;
    }

    function build_db_join_relation($related_table, $unique_name, $related_primary_key, $field_name) {
        $onString1 = str_replace('"', ' ', $this->protect_identifiers($unique_name.'.'.$related_primary_key));
        $onString2 = str_replace('"', ' ', $this->protect_identifiers($this->table_name.'.'.$field_name));//var_dump($onString2);exit;
        $this->db->join("{$this->protect_identifiers($related_table)} as {$this->protect_identifiers($unique_name)}", "{$onString1} = {$onString2}",'left');
    }

    function build_relation_n_n_subquery($field, $selection_table, $relation_table, $primary_key_alias_to_selection_table, $primary_key_selection_table, $primary_key_alias_to_this_table, $field_name){
        return "(
        --  SELECT GROUP_CONCAT(DISTINCT ".$this->protect_identifiers($field).")
            SELECT array_agg(".$this->protect_identifiers($field).")
                FROM ".$this->protect_identifiers($selection_table) ."
            LEFT JOIN ".$this->protect_identifiers($relation_table)."
                ON ".$this->protect_identifiers($relation_table.".".$primary_key_alias_to_selection_table)." = ".$this->protect_identifiers($selection_table.".".$primary_key_selection_table) ."
            WHERE ".$this->protect_identifiers($relation_table.".".$primary_key_alias_to_this_table)." = ".$this->protect_identifiers($this->table_name.".".$this->get_primary_key($this->table_name))."
            GROUP BY ".$this->protect_identifiers($relation_table.".".$primary_key_alias_to_this_table)."
        ) AS ".$this->protect_identifiers($field_name);
    }

    function db_delete($primary_key_value) {
    	$primary_key_field = $this->get_primary_key();

    	if($primary_key_field === false)
    		return false;

    	$this->db->delete($this->table_name,array( $primary_key_field => $primary_key_value));
    	if( $this->db->affected_rows() != 1)
    		return false;
    	else
    		return true;
    }

    function field_exists($field,$table_name = null) {
    	if(empty($table_name))
    	    $table_name = $this->table_name;

        // sqlite doesn't support this $this->db->field_exists($field, $table_name)
        $field_data_list = $this->db->field_data($table_name);
        foreach($field_data_list as $field_data){
            if($field_data->name == $field) return TRUE;
        }
        return FALSE;
    }

    function get_edit_values($primary_key_value) {
        $result = parent::get_edit_values($primary_key_value);
        // some driver like postgresql doesn't return string
        foreach($result as $key => $value) {
            $result->$key = (string)$value;
        }

        return $result;
    }
}