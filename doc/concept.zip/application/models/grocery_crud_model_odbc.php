<?php
class grocery_crud_model_ODBC extends grocery_CRUD_Generic_Model{

}
