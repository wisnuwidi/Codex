<?php
class grocery_crud_model_MSSQL extends grocery_CRUD_Generic_Model{

}
